﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace jogodavelha
{
    public partial class Form1 : Form
    {
      
        string turn = "X";
        bool player = false;
        public Form1()
        {
            InitializeComponent();
        }
        
        public void Form1_Load(object sender, EventArgs e)
        {
            label1.Text = "";
            label2.Text = "";
            label3.Text = "";
            label4.Text = "";
            label5.Text = "";
            label6.Text = "";
            label7.Text = "";
            label8.Text = "";
            label9.Text = "";
        }
       
        
        private void button1_Click(object sender, EventArgs e)
        {
            WinCon();
            int line = int.Parse(comboBox1.Text);
            int column = int.Parse(comboBox2.Text);
            //ganhou?
            
            //jogo em si
            if (line == 0 && column == 0 && label1.Text == "")
            { 
                if(player == false)
                {
                    player = true;
                    turn = "X";
                }
                else if (player == true)
                {
                    player = false;
                    turn = "O";
                }
                label1.Text = turn;
            }
            else
            if (line == 0 && column == 1 && label2.Text == "")
            {
                if (player == false)
                {
                    player = true;
                    turn = "X";
                }
                else if (player == true)
                {
                    player = false;
                    turn = "O";
                }
                label2.Text = turn;
            }
            else
            if (line == 0 && column == 2 && label3.Text == "")
            {
                if (player == false)
                {
                    player = true;
                    turn = "X";
                }
                else if (player == true)
                {
                    player = false;
                    turn = "O";
                }
                label3.Text = turn;

            }
            else
            if (line == 1 && column == 0 && label4.Text == "")
            {
                if (player == false)
                {
                    player = true;
                    turn = "X";
                }
                else if (player == true)
                {
                    player = false;
                    turn = "O";
                }
                label4.Text = turn;
            }
            else
            if (line == 1 && column == 1 && label5.Text == "")
            {
                if (player == false)
                {
                    player = true;
                    turn = "X";
                }
                else if (player == true)
                {
                    player = false;
                    turn = "O";
                }
                label5.Text = turn;
            }
            else
            if (line == 1 && column == 2 && label6.Text == "")
            {
                if (player == false)
                {
                    player = true;
                    turn = "X";
                }
                else if (player == true)
                {
                    player = false;
                    turn = "O";
                }
                label6.Text = turn;
            }
            else
            if (line == 2 && column == 0 && label7.Text == "")
            {
                if (player == false)
                {
                    player = true;
                    turn = "X";
                }
                else if (player == true)
                {
                    player = false;
                    turn = "O";
                }
                label7.Text = turn;
            }
            else
            if (line == 2 && column == 1 && label8.Text == "")
            {
                if (player == false)
                {
                    player = true;
                    turn = "X";
                }
                else if (player == true)
                {
                    player = false;
                    turn = "O";
                }
                label8.Text = turn;
            }
            else
            if (line == 2 && column == 2 && label9.Text == "")
            {
                if (player == false)
                {
                    player = true;
                    turn = "X";
                }
                else if (player == true)
                {
                    player = false;
                    turn = "O";
                }
                label9.Text = turn;
            }
        }
        void WinCon()
        {
            if (label1.Text == "X" && label2.Text == "X" && label3.Text == "X")
            {
                MessageBox.Show("X ganhou!");
                Clear();
            }
            if (label4.Text == "X" && label5.Text == "X" && label6.Text == "X")
            {
                MessageBox.Show("X ganhou!");
                Clear();
            }
            if (label7.Text == "X" && label8.Text == "X" && label9.Text == "X")
            {
                MessageBox.Show("X ganhou!");
                Clear();
            }
            if (label2.Text == "X" && label5.Text == "X" && label6.Text == "X")
            {
                MessageBox.Show("X ganhou!");
                Clear();
            }
            if (label3.Text == "X" && label6.Text == "X" && label9.Text == "X")
            {
                MessageBox.Show("X ganhou!");
                Clear();
            }
            if (label1.Text == "X" && label4.Text == "X" && label7.Text == "X")
            {
                MessageBox.Show("X ganhou!");
                Clear();
            }
            if (label1.Text == "X" && label5.Text == "X" && label9.Text == "X")
            {
                MessageBox.Show("X ganhou!");
                Clear();
            }
            if (label3.Text == "X" && label5.Text == "X" && label7.Text == "X")
            {
                MessageBox.Show("X ganhou!");
                Clear();
            }
            if (label1.Text == "O" && label2.Text == "O" && label3.Text == "O")
            {
                MessageBox.Show("O ganhou!");
                Clear();
            }
            if (label4.Text == "O" && label5.Text == "0" && label6.Text == "0")
            {
                MessageBox.Show("0 ganhou!");
                Clear();
            }
            if (label7.Text == "0" && label8.Text == "O" && label9.Text == "O")
            {
                MessageBox.Show("O ganhou!");
                Clear();
            }
            if (label2.Text == "O" && label5.Text == "O" && label6.Text == "O")
            {
                MessageBox.Show("O ganhou!");
                Clear();
            }
            if (label3.Text == "O" && label6.Text == "O" && label9.Text == "O")
            {
                MessageBox.Show("O ganhou!");
                Clear();
            }
            if (label1.Text == "O" && label4.Text == "O" && label7.Text == "O")
            {
                MessageBox.Show("O ganhou!");
                Clear();
            }
            if (label1.Text == "O" && label5.Text == "O" && label9.Text == "O")
            {
                MessageBox.Show("O ganhou!");
                Clear();
            }
            if (label3.Text == "O" && label5.Text == "O" && label7.Text == "O")
            {
                MessageBox.Show("O ganhou!");
                Clear();
            }
           
        }
        void Clear()
        {
            label1.Text = "";
            label2.Text = "";
            label3.Text = "";
            label4.Text = "";
            label5.Text = "";
            label6.Text = "";
            label7.Text = "";
            label8.Text = "";
            label9.Text = "";
        }
    }
}
